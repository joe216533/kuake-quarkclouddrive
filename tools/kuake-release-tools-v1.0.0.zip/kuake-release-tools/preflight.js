#!/usr/bin/env node
/**
 * 技能发布预检（preflight）
 *
 * 用法:
 *   node preflight.js <zip路径> [--url <直链>] [--skill <技能源目录>]
 *
 * 检查项:
 *   ① 包内禁止内容（token / config.json / runtime / 缓存）
 *   ② ZIP 完整性 + SHA256 与同名 .sha256 一致
 *   ③ SKILL.md 与 manifest.json 的 name/version 一致
 *   ④ 直链可达且字节数一致（传入 --url 时）
 *
 * 退出码: 0 通过 / 1 存在阻断项 / 2 仅警告
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const zlib = require('zlib');
const https = require('https');

const FORBID = [
  /(^|\/)runtime\//i,
  /(^|\/)workbuddy\/config\.json$/i,
  /(^|\/)config\.json$/i,
  /\.token$/i,
  /(^|\/)\.env/i,
  /(^|\/)credentials/i,
  /(^|\/)browse\//i,
  /(^|\/)downloads\//i,
  /_e2e\//i,
  /\.log$/i,
  // 隐藏文件/隐藏目录（.backup、.git、.old 等）：打包脚本不过滤，必须在此拦截
  /(^|\/)\.[^/]+/,
  // 备份类命名，即使不带点也拦
  /(^|\/)(backup|BACKUP|old|OLD|previous|_bak)[^/]*\//,
];

const errors = [];
const warns = [];
const ok = (m) => console.log('PASS  ' + m);
const bad = (m) => { errors.push(m); console.log('FAIL  ' + m); };
const warn = (m) => { warns.push(m); console.log('WARN  ' + m); };

function readZipNames(buf) {
  const EOCD = 0x06054b50;
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 66000); i--) {
    if (buf.readUInt32LE(i) === EOCD) { eocd = i; break; }
  }
  if (eocd < 0) throw new Error('不是有效 zip');
  const count = buf.readUInt16LE(eocd + 10);
  let off = buf.readUInt32LE(eocd + 16);
  const names = [];
  for (let n = 0; n < count; n++) {
    if (buf.readUInt32LE(off) !== 0x02014b50) break;
    const nameLen = buf.readUInt16LE(off + 28);
    const extraLen = buf.readUInt16LE(off + 30);
    const commentLen = buf.readUInt16LE(off + 32);
    names.push(buf.toString('utf8', off + 46, off + 46 + nameLen));
    off += 46 + nameLen + extraLen + commentLen;
  }
  return names;
}

function readZipEntry(buf, target) {
  const EOCD = 0x06054b50;
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 66000); i--) {
    if (buf.readUInt32LE(i) === EOCD) { eocd = i; break; }
  }
  const count = buf.readUInt16LE(eocd + 10);
  let off = buf.readUInt32LE(eocd + 16);
  for (let n = 0; n < count; n++) {
    if (buf.readUInt32LE(off) !== 0x02014b50) break;
    const method = buf.readUInt16LE(off + 10);
    const compSize = buf.readUInt32LE(off + 20);
    const nameLen = buf.readUInt16LE(off + 28);
    const extraLen = buf.readUInt16LE(off + 30);
    const commentLen = buf.readUInt16LE(off + 32);
    const localOff = buf.readUInt32LE(off + 42);
    const name = buf.toString('utf8', off + 46, off + 46 + nameLen);
    if (name === target || name.endsWith('/' + target)) {
      const lo = localOff;
      const nl = buf.readUInt16LE(lo + 26);
      const el = buf.readUInt16LE(lo + 28);
      const start = lo + 30 + nl + el;
      const data = buf.subarray(start, start + compSize);
      return method === 0 ? Buffer.from(data) : zlib.inflateRawSync(data);
    }
    off += 46 + nameLen + extraLen + commentLen;
  }
  return null;
}

function httpHead(url, redirects = 0) {
  return new Promise((resolve) => {
    if (redirects > 5) return resolve({ code: 0, size: 0 });
    https.get(url, { headers: { 'User-Agent': 'preflight/1.0' } }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        res.resume();
        return resolve(httpHead(res.headers.location, redirects + 1));
      }
      const len = Number(res.headers['content-length'] || 0);
      res.resume();
      resolve({ code: res.statusCode, size: len });
    }).on('error', () => resolve({ code: 0, size: 0 }));
  });
}

(async () => {
  const zipPath = process.argv[2];
  if (!zipPath) { console.error('用法: node preflight.js <zip> [--url <直链>]'); process.exit(1); }
  const urlIdx = process.argv.indexOf('--url');
  const testUrl = urlIdx > 0 ? process.argv[urlIdx + 1] : null;

  console.log('=== 技能发布预检 ===\n');
  if (!fs.existsSync(zipPath)) { bad(`找不到文件 ${zipPath}`); return done(); }

  const buf = fs.readFileSync(zipPath);
  // ① 禁止内容
  let names = [];
  try { names = readZipNames(buf); } catch (e) { bad(`ZIP 解析失败: ${e.message}`); return done(); }
  const hits = names.filter((n) => FORBID.some((re) => re.test(n)));
  if (hits.length) bad(`包内含禁止内容: ${hits.slice(0, 8).join(', ')}`);
  else ok(`包内无禁止内容（${names.length} 个条目）`);

  // ② 完整性 + SHA256
  const shaFile = zipPath + '.sha256';
  const actual = crypto.createHash('sha256').update(buf).digest('hex');
  if (!fs.existsSync(shaFile)) warn(`缺少校验文件 ${path.basename(shaFile)}`);
  else {
    const expect = fs.readFileSync(shaFile, 'utf8').trim().split(/\s+/)[0];
    if (expect === actual) ok(`SHA256 一致 ${actual.slice(0, 16)}…`);
    else bad(`SHA256 不一致：记录 ${expect.slice(0, 16)}… / 实际 ${actual.slice(0, 16)}…`);
  }
  if (buf.length === 0) bad('ZIP 为空'); else ok(`文件大小 ${buf.length} 字节`);

  // ③ name / version 一致性
  try {
    const skillMd = readZipEntry(buf, 'SKILL.md');
    const manBuf = readZipEntry(buf, 'manifest.json');
    const skillName = skillMd ? (skillMd.toString('utf8').match(/^name:\s*(.+)$/m) || [])[1] : null;
    const skillVer = skillMd ? (skillMd.toString('utf8').match(/^version:\s*"?(.+?)"?$/m) || [])[1] : null;
    const man = manBuf ? JSON.parse(manBuf.toString('utf8')) : null;
    if (!skillName || !man) bad('缺少 SKILL.md 或 manifest.json');
    else {
      if (man.id !== skillName.trim()) bad(`name 不一致：SKILL=${skillName.trim()} / manifest=${man.id}`);
      else ok(`技能名一致 ${skillName.trim()}`);
      if (man.version !== skillVer.trim()) bad(`版本不一致：SKILL=${skillVer.trim()} / manifest=${man.version}`);
      else ok(`版本一致 v${man.version}`);
    }
  } catch (e) { bad(`读取元信息失败: ${e.message}`); }

  // ④ 直链
  if (testUrl) {
    const r = await httpHead(testUrl);
    if (r.code !== 200) bad(`直链返回 ${r.code}`);
    else if (r.size && r.size !== buf.length) bad(`直链大小 ${r.size} 与本地 ${buf.length} 不一致`);
    else ok(`直链可达 ${r.code}，大小 ${r.size || '未返回'} `);
  } else {
    warn('未提供 --url，跳过直链检查');
  }

  done();
})();

function done() {
  console.log(`\n=== 阻断 ${errors.length} 项 / 警告 ${warns.length} 项 ===`);
  if (errors.length) { console.log('结论：不得发布。'); process.exit(1); }
  if (warns.length) { console.log('结论：可发布，但需处理警告项。'); process.exit(2); }
  console.log('结论：预检通过。');
  process.exit(0);
}
