# kuake-release-tools v1.0.0

夸克技能（`kuake-quarkclouddrive`）的**发布工具包**，供执行方在开发/发版时使用。

**这不是用户安装用的技能包。** 用户安装用的是 `kuake-quarkclouddrive-v<x.y.z>.zip`（含 SKILL.md 与 install.js），本工具包是给"开发/发布技能的人"用的三件套。

## 一、包含什么

| 文件 | 作用 | 调用方式 |
|-|-|-|
| `release.sh` | 正式发布入口：一条命令完成版本号同步、打包、SHA256、preflight、GitHub 推送+tag、双链验证、夸克上传、归档旧版、建公开永久分享 | `./release.sh <版本号> [--delete-old-quark]` |
| `preflight.js` | 发布前门禁：包内禁止内容、ZIP 完整性、SHA256、技能名/版本一致 | `node preflight.js <zip> [--url <直链>]` |
| `check-sync.js` | 发布后同步验收：比对 GitHub / 夸克 / 飞书三处版本、包名、字节数，退出码 0=一致 / 1=不一致 / 2=受阻 | `node check-sync.js [技能英文名]` |
| `release-manifest.example.json` | 发布记录的脱敏样例（字段结构，非真实数据） | 参考用，不要直接当真实记录 |

`publish.sh`、`vpn.py` **不在本工具包内**：前者是废弃旧脚本（只做旧版 GitHub 六步），后者已从现行网络方案移除。

## 二、运行环境与依赖

- Node.js ≥ 16（本工具包在 Node 22 实测）；
- `git` 已配置目标仓库的凭据（fine-grained PAT，或 `~/.git-credentials`）与**仓库级代理**；
- 夸克 CLI `quark-drive.cjs`（技能安装时由 `install.js` 从官方接口现取，路径见下方 `KQ_QCLI`）；
- `lark-cli`（仅 `check-sync.js` 读飞书时需要，路径见 `KQ_LARK`）；
- `curl`（`release.sh` 验证直链、`check-sync.js` 访问 GitHub API 时需要）。

## 三、环境变量（**必须按本机实际设置**）

三个脚本里的路径/身份/代理都有默认值，但**那些默认值是发布者本机的示例，不是通用值**。在其他机器使用必须显式设置：

| 变量 | 含义 | 示例 |
|-|-|-|
| `KQ_BASE` | 发布包工作目录（含技能目录、gh-repo、zip） | `/path/to/发布包` |
| `KQ_REPO_DIR` | Git 仓库目录，默认 `$KQ_BASE/gh-repo` | `/path/to/gh-repo` |
| `KQ_QCLI` | 夸克 CLI 路径 | `/path/to/quark-drive.cjs` |
| `KQ_SKILL_CREATOR` | 技能打包脚本 `package_skill.py` 所在目录 | `/path/to/skill-creator` |
| `KQ_LARK` | `lark-cli` 可执行文件（Windows 为 `.cmd`） | `/path/to/lark-cli.cmd` |
| `KQ_QUARK_DIR` | 夸克"技能包"目录 FID | `<从夸克 CLI browse 获取>` |
| `KQ_PROXY` | GitHub 访问代理 | `http://127.0.0.1:11719` |
| `KQ_OWNER` / `KQ_REPO` | GitHub 用户名 / 仓库名 | `joe216533` / `kuake-quarkclouddrive` |
| `KQ_GIT_EMAIL` / `KQ_GIT_NAME` | git 提交身份 | — |
| `KQ_DOC` | 飞书目录指南链接（check-sync 用） | `https://…/docx/<id>` |

**网络隔离原则**（重要）：GitHub 走仓库级代理（`git config http.proxy <KQ_PROXY>`，只对当前仓库生效），GPT 浏览器走浏览器级 `--proxy-server`，**全局 VPN 保持国内直连不要切换**——夸克必须国内直连，走境外出口会报 `1007`。不要使用旧的 `vpn.py off` / 全局开关方案。

## 四、下载渠道优先级（**老板明确规定**）

获取本工具包时：

1. **优先从夸克网盘下载**——正式备份渠道，永久、无提取码分享；
2. **仅当夸克下载失败**（例如分享被删除、链接失效、网络受限）时，才改用 **GitHub 固定 tag 直链**。

两个渠道的 ZIP 内容相同、SHA256 一致。下载后**先核对 SHA256 再解压执行**，不要凭文件名或链接标题认定版本正确。

## 五、使用流程（简要）

```bash
# 0. 设置环境变量（见第三节），并验证 git 仓库级代理
git -C "$KQ_REPO_DIR" config http.proxy "$KQ_PROXY"

# 1. 发布前预检
node preflight.js "$KQ_BASE/kuake-quarkclouddrive-v1.0.4.zip"

# 2. 正式发布（会真实写 GitHub 与夸克，需老板批准）
./release.sh 1.0.4 --delete-old-quark

# 3. 发布后同步验收
node check-sync.js kuake-quarkclouddrive
```

预检退出码：0=通过 / 1=阻断项 / 2=警告（如未提供直链，属预期）。
check-sync 退出码：0=三处一致 / 1=不一致 / 2=检查受阻。

## 六、审批与权限边界

- `release.sh` 会**真实写 GitHub 仓库、上传/归档夸克网盘、创建公开分享**——这些操作必须经老板批准后才能执行；
- 拿到本工具包 ≠ 获得发版授权。工具只是能力，审批边界不变；
- 脚本遇到扫码、风控、权限不足时按实际结果停止并报告，不得虚报成功；
- 任何账号凭据、token、cookies、个人配置都不得写进工具包或提交到仓库。

## 七、完整性

本工具包以独立版本号管理（`kuake-release-tools v1.0.0`），不跟随技能包版本。
ZIP 外附 `.sha256` 校验文件。夸克与 GitHub 两个渠道下载所得文件的 SHA256 必须一致。
